import { motion } from 'motion/react';
import { Calculator, Camera, Code, Paintbrush, PenTool, Presentation, Scissors, Zap } from 'lucide-react';

export default function Landing({ onStart }: { onStart: () => void }) {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="p-6 flex justify-between items-center max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2 text-emerald-500 font-bold text-xl tracking-tight">
          <Calculator className="w-6 h-6" />
          <span>Quanto Cobrar?</span>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-6 text-center max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-white mb-6 leading-tight">
            Descubra se você está cobrando <span className="text-emerald-500">certo</span> pelo seu trabalho.
          </h1>
          <p className="text-lg md:text-xl text-zinc-400 mb-10 max-w-2xl mx-auto">
            87% dos freelancers cobram menos do que deveriam. Calcule seu preço ideal em 2 minutos e pare de pagar para trabalhar.
          </p>
          <button
            onClick={onStart}
            className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-lg px-8 py-4 rounded-full transition-all transform hover:scale-105 shadow-[0_0_40px_-10px_rgba(16,185,129,0.5)] cursor-pointer"
          >
            Calcular Meu Preço — Grátis
          </button>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-20 w-full"
        >
          <p className="text-sm text-zinc-500 mb-6 uppercase tracking-widest font-semibold">Profissões Atendidas</p>
          <div className="flex flex-wrap justify-center gap-8 text-zinc-600">
            <div className="flex flex-col items-center gap-2"><Paintbrush className="w-8 h-8" /><span className="text-xs">Designer</span></div>
            <div className="flex flex-col items-center gap-2"><Code className="w-8 h-8" /><span className="text-xs">Dev</span></div>
            <div className="flex flex-col items-center gap-2"><Camera className="w-8 h-8" /><span className="text-xs">Fotógrafo</span></div>
            <div className="flex flex-col items-center gap-2"><PenTool className="w-8 h-8" /><span className="text-xs">Social Media</span></div>
            <div className="flex flex-col items-center gap-2"><Presentation className="w-8 h-8" /><span className="text-xs">Professor</span></div>
            <div className="flex flex-col items-center gap-2"><Zap className="w-8 h-8" /><span className="text-xs">Eletricista</span></div>
            <div className="flex flex-col items-center gap-2"><Scissors className="w-8 h-8" /><span className="text-xs">Beleza</span></div>
          </div>
        </motion.div>
      </main>

      <footer className="p-6 text-center text-zinc-600 text-sm flex justify-center gap-6">
        <a href="#" className="hover:text-emerald-500 transition-colors">Sobre</a>
        <a href="#" className="hover:text-emerald-500 transition-colors">Metodologia de cálculo</a>
      </footer>
    </div>
  );
}
