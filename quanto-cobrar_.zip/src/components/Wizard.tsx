import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, ArrowLeft, User, DollarSign, Clock, Target, CheckCircle2 } from 'lucide-react';

const PROFESSIONS = ['Designer', 'Fotógrafo', 'Programador', 'Confeiteira', 'Social Media', 'Professor Particular', 'Personal Trainer', 'Manicure', 'Eletricista', 'Outros'];
const EXPERIENCES = ['Iniciante', 'Intermediário', 'Experiente', 'Especialista'];
const TAX_REGIMES = ['MEI', 'Simples Nacional', 'Informal'];

export default function Wizard({ onComplete }: { onComplete: (data: any) => void }) {
  const [step, setStep] = useState(1);
  const [data, setData] = useState({
    profession: '', experience: '', city: '', state: '',
    fixedCosts: '', variableCosts: '', taxRegime: '',
    hoursPerDay: '8', daysPerWeek: '5', vacationWeeks: '4', hoursPerProject: '',
    desiredNetIncome: '', currentProjectPrice: ''
  });

  const updateData = (field: string, value: string) => setData(prev => ({ ...prev, [field]: value }));

  const nextStep = () => setStep(s => Math.min(s + 1, 4));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const handleComplete = () => {
    onComplete({
      ...data,
      fixedCosts: Number(data.fixedCosts) || 0,
      variableCosts: Number(data.variableCosts) || 0,
      hoursPerDay: Number(data.hoursPerDay) || 8,
      daysPerWeek: Number(data.daysPerWeek) || 5,
      vacationWeeks: Number(data.vacationWeeks) || 4,
      hoursPerProject: Number(data.hoursPerProject) || 10,
      desiredNetIncome: Number(data.desiredNetIncome) || 3000,
      currentProjectPrice: Number(data.currentProjectPrice) || 0,
    });
  };

  const steps = [
    { id: 1, title: 'Perfil', icon: User },
    { id: 2, title: 'Custos', icon: DollarSign },
    { id: 3, title: 'Tempo', icon: Clock },
    { id: 4, title: 'Objetivos', icon: Target },
  ];

  return (
    <div className="min-h-screen flex flex-col items-center py-12 px-4 sm:px-6">
      <div className="w-full max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            {steps.map(s => {
              const Icon = s.icon;
              const isActive = s.id === step;
              const isPast = s.id < step;
              return (
                <div key={s.id} className={`flex flex-col items-center gap-2 ${isActive ? 'text-emerald-500' : isPast ? 'text-emerald-700' : 'text-zinc-600'}`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${isActive ? 'border-emerald-500 bg-emerald-500/10' : isPast ? 'border-emerald-700 bg-emerald-900/20' : 'border-zinc-800 bg-zinc-900'}`}>
                    {isPast ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
                  </div>
                  <span className="text-xs font-medium hidden sm:block">{s.title}</span>
                </div>
              );
            })}
          </div>
          <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-emerald-500"
              initial={{ width: '25%' }}
              animate={{ width: `${(step / 4) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        {/* Form Content */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 sm:p-10 shadow-xl relative overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {step === 1 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Conte-nos sobre você</h2>
                  
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Profissão</label>
                    <select 
                      value={data.profession} 
                      onChange={e => updateData('profession', e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                    >
                      <option value="" disabled>Selecione sua profissão</option>
                      {PROFESSIONS.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Nível de Experiência</label>
                    <div className="grid grid-cols-2 gap-3">
                      {EXPERIENCES.map(exp => (
                        <button
                          key={exp}
                          onClick={() => updateData('experience', exp)}
                          className={`px-4 py-3 rounded-xl border text-sm font-medium transition-all cursor-pointer ${data.experience === exp ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'}`}
                        >
                          {exp}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Cidade</label>
                      <input 
                        type="text" 
                        value={data.city} 
                        onChange={e => updateData('city', e.target.value)}
                        placeholder="Ex: São Paulo"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Estado</label>
                      <input 
                        type="text" 
                        value={data.state} 
                        onChange={e => updateData('state', e.target.value)}
                        placeholder="Ex: SP"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Seus Custos</h2>
                  
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Custos Fixos Mensais (R$)</label>
                    <p className="text-xs text-zinc-500 mb-3">Ex: Internet, energia, softwares, aluguel, celular.</p>
                    <div className="relative">
                      <span className="absolute left-4 top-3.5 text-zinc-500">R$</span>
                      <input 
                        type="number" 
                        value={data.fixedCosts} 
                        onChange={e => updateData('fixedCosts', e.target.value)}
                        placeholder="0,00"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-12 pr-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Custos Variáveis por Projeto (R$)</label>
                    <p className="text-xs text-zinc-500 mb-3">Ex: Deslocamento, materiais específicos, terceirização.</p>
                    <div className="relative">
                      <span className="absolute left-4 top-3.5 text-zinc-500">R$</span>
                      <input 
                        type="number" 
                        value={data.variableCosts} 
                        onChange={e => updateData('variableCosts', e.target.value)}
                        placeholder="0,00"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-12 pr-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Regime Tributário</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {TAX_REGIMES.map(regime => (
                        <button
                          key={regime}
                          onClick={() => updateData('taxRegime', regime)}
                          className={`px-4 py-3 rounded-xl border text-sm font-medium transition-all cursor-pointer ${data.taxRegime === regime ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'}`}
                        >
                          {regime}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Seu Tempo</h2>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Horas produtivas por dia</label>
                      <input 
                        type="number" 
                        value={data.hoursPerDay} 
                        onChange={e => updateData('hoursPerDay', e.target.value)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Dias trabalhados por semana</label>
                      <input 
                        type="number" 
                        value={data.daysPerWeek} 
                        onChange={e => updateData('daysPerWeek', e.target.value)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Semanas de férias por ano</label>
                      <input 
                        type="number" 
                        value={data.vacationWeeks} 
                        onChange={e => updateData('vacationWeeks', e.target.value)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Tempo médio por projeto (horas)</label>
                      <input 
                        type="number" 
                        value={data.hoursPerProject} 
                        onChange={e => updateData('hoursPerProject', e.target.value)}
                        placeholder="Ex: 20"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Seus Objetivos</h2>
                  
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Renda Líquida Desejada por Mês (R$)</label>
                    <p className="text-xs text-zinc-500 mb-3">Quanto você quer que sobre no seu bolso livre de impostos e custos da empresa.</p>
                    <div className="relative">
                      <span className="absolute left-4 top-3.5 text-zinc-500">R$</span>
                      <input 
                        type="number" 
                        value={data.desiredNetIncome} 
                        onChange={e => updateData('desiredNetIncome', e.target.value)}
                        placeholder="5000,00"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-12 pr-4 py-3 text-white text-xl font-bold focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Preço médio cobrado atualmente por projeto (R$)</label>
                    <p className="text-xs text-zinc-500 mb-3">Opcional. Usado para comparar com o seu preço ideal.</p>
                    <div className="relative">
                      <span className="absolute left-4 top-3.5 text-zinc-500">R$</span>
                      <input 
                        type="number" 
                        value={data.currentProjectPrice} 
                        onChange={e => updateData('currentProjectPrice', e.target.value)}
                        placeholder="0,00"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-12 pr-4 py-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="mt-10 flex justify-between pt-6 border-t border-zinc-800">
            {step > 1 ? (
              <button 
                onClick={prevStep}
                className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors px-4 py-2 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Voltar
              </button>
            ) : <div />}
            
            {step < 4 ? (
              <button 
                onClick={nextStep}
                className="flex items-center gap-2 bg-white text-zinc-950 hover:bg-zinc-200 font-medium px-6 py-2.5 rounded-xl transition-colors cursor-pointer"
              >
                Próximo <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button 
                onClick={handleComplete}
                className="flex items-center gap-2 bg-emerald-500 text-zinc-950 hover:bg-emerald-400 font-bold px-8 py-2.5 rounded-xl transition-colors shadow-[0_0_20px_-5px_rgba(16,185,129,0.4)] cursor-pointer"
              >
                Ver Resultado <CheckCircle2 className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
