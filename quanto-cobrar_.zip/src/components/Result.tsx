import { motion } from 'motion/react';
import { AlertTriangle, Share2, RefreshCcw, Download, CheckCircle2, XCircle } from 'lucide-react';

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

export default function Result({ data, onRestart }: { data: any, onRestart: () => void }) {
  // Calculations
  const workingWeeksPerYear = 52 - data.vacationWeeks;
  const workingHoursPerMonth = (workingWeeksPerYear / 12) * data.daysPerWeek * data.hoursPerDay;
  const billableHoursPerMonth = workingHoursPerMonth * 0.8; // 80% efficiency

  let taxRate = 0;
  let fixedTax = 0;
  if (data.taxRegime === 'MEI') fixedTax = 75;
  if (data.taxRegime === 'Simples Nacional') taxRate = 0.06;

  // Ideal
  const idealGross = (data.desiredNetIncome + data.fixedCosts + fixedTax) / (1 - taxRate);
  const idealHourly = idealGross / billableHoursPerMonth;
  const idealProject = (idealHourly * data.hoursPerProject) + data.variableCosts;

  // Healthy (80% of desired net)
  const healthyGross = ((data.desiredNetIncome * 0.8) + data.fixedCosts + fixedTax) / (1 - taxRate);
  const healthyHourly = healthyGross / billableHoursPerMonth;
  const healthyProject = (healthyHourly * data.hoursPerProject) + data.variableCosts;

  // Minimum (covers fixed costs + 1 min wage or 50% of desired net)
  const minNet = Math.max(data.desiredNetIncome * 0.5, 1412);
  const minGross = (minNet + data.fixedCosts + fixedTax) / (1 - taxRate);
  const minHourly = minGross / billableHoursPerMonth;
  const minProject = (minHourly * data.hoursPerProject) + data.variableCosts;

  const clientsNeededIdeal = Math.ceil(idealGross / idealProject);
  const estimatedTax = idealGross * taxRate + fixedTax;

  const isUndercharging = data.currentProjectPrice > 0 && data.currentProjectPrice < minProject;

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 max-w-6xl mx-auto">
      <header className="mb-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Seu Diagnóstico de Preço</h1>
          <p className="text-zinc-400 mt-1">Baseado nos seus custos e meta de {formatCurrency(data.desiredNetIncome)}/mês</p>
        </div>
        <div className="flex gap-3">
          <button onClick={onRestart} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-zinc-800 text-zinc-300 hover:bg-zinc-800 transition-colors text-sm font-medium cursor-pointer">
            <RefreshCcw className="w-4 h-4" /> Refazer
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 text-zinc-950 hover:bg-emerald-400 transition-colors text-sm font-bold cursor-pointer">
            <Share2 className="w-4 h-4" /> Compartilhar
          </button>
        </div>
      </header>

      {isUndercharging && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 mb-8 flex gap-4 items-start"
        >
          <AlertTriangle className="w-6 h-6 text-red-500 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-red-400 font-bold">Alerta: Você está cobrando muito pouco!</h3>
            <p className="text-red-200/70 text-sm mt-1">
              Seu preço atual ({formatCurrency(data.currentProjectPrice)}) está abaixo do mínimo viável ({formatCurrency(minProject)}). 
              Isso significa que você pode estar pagando para trabalhar ou não conseguirá atingir suas metas financeiras.
            </p>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Minimum Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-zinc-900 border border-red-500/30 rounded-2xl p-6 relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-red-500" />
          <h3 className="text-zinc-400 font-medium flex items-center gap-2"><XCircle className="w-4 h-4 text-red-500" /> Preço Mínimo</h3>
          <p className="text-xs text-zinc-500 mt-1 mb-4">Cobre custos e sobrevivência</p>
          <div className="mb-4">
            <span className="text-3xl font-bold text-white">{formatCurrency(minProject)}</span>
            <span className="text-zinc-500 text-sm"> /projeto</span>
          </div>
          <div className="text-sm text-zinc-400 border-t border-zinc-800 pt-4">
            <span className="text-white font-medium">{formatCurrency(minHourly)}</span> /hora
          </div>
        </motion.div>

        {/* Healthy Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-zinc-900 border border-yellow-500/30 rounded-2xl p-6 relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-yellow-500" />
          <h3 className="text-zinc-400 font-medium flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-yellow-500" /> Preço Saudável</h3>
          <p className="text-xs text-zinc-500 mt-1 mb-4">Atinge 80% da sua meta</p>
          <div className="mb-4">
            <span className="text-3xl font-bold text-white">{formatCurrency(healthyProject)}</span>
            <span className="text-zinc-500 text-sm"> /projeto</span>
          </div>
          <div className="text-sm text-zinc-400 border-t border-zinc-800 pt-4">
            <span className="text-white font-medium">{formatCurrency(healthyHourly)}</span> /hora
          </div>
        </motion.div>

        {/* Ideal Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-zinc-900 border border-emerald-500/50 rounded-2xl p-6 relative overflow-hidden shadow-[0_0_30px_-10px_rgba(16,185,129,0.2)]"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500" />
          <div className="absolute top-4 right-4 bg-emerald-500/20 text-emerald-400 text-xs font-bold px-2 py-1 rounded">ALVO</div>
          <h3 className="text-zinc-400 font-medium flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> Preço Ideal</h3>
          <p className="text-xs text-zinc-500 mt-1 mb-4">Atinge 100% da sua meta</p>
          <div className="mb-4">
            <span className="text-4xl font-extrabold text-emerald-400">{formatCurrency(idealProject)}</span>
            <span className="text-zinc-500 text-sm"> /projeto</span>
          </div>
          <div className="text-sm text-zinc-400 border-t border-zinc-800 pt-4">
            <span className="text-white font-medium">{formatCurrency(idealHourly)}</span> /hora
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-white mb-4">Resumo Mensal Necessário</h3>
            <ul className="space-y-4">
              <li className="flex justify-between items-center">
                <span className="text-zinc-400 text-sm">Faturamento Bruto</span>
                <span className="text-white font-medium">{formatCurrency(idealGross)}</span>
              </li>
              <li className="flex justify-between items-center">
                <span className="text-zinc-400 text-sm">Impostos Estimados</span>
                <span className="text-red-400 font-medium">-{formatCurrency(estimatedTax)}</span>
              </li>
              <li className="flex justify-between items-center">
                <span className="text-zinc-400 text-sm">Custos Fixos</span>
                <span className="text-red-400 font-medium">-{formatCurrency(data.fixedCosts)}</span>
              </li>
              <li className="flex justify-between items-center pt-3 border-t border-zinc-800">
                <span className="text-zinc-300 font-medium">Renda Líquida</span>
                <span className="text-emerald-400 font-bold">{formatCurrency(data.desiredNetIncome)}</span>
              </li>
            </ul>
          </div>

          <div className="bg-emerald-900/20 border border-emerald-500/20 rounded-2xl p-6 text-center">
            <h3 className="text-emerald-400 font-bold mb-2">Meta de Clientes</h3>
            <p className="text-zinc-300 text-sm mb-4">Para atingir sua renda ideal cobrando o valor por projeto, você precisa fechar:</p>
            <div className="text-5xl font-black text-white mb-2">{clientsNeededIdeal}</div>
            <p className="text-zinc-400 text-sm">projetos por mês</p>
          </div>
        </div>

        <div className="lg:col-span-2 bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-white">Tabela de Serviços Sugerida</h3>
            <button className="text-emerald-500 hover:text-emerald-400 text-sm font-medium flex items-center gap-1 cursor-pointer">
              <Download className="w-4 h-4" /> Baixar PDF
            </button>
          </div>
          
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-500 text-sm">
                  <th className="pb-3 font-medium">Tipo de Serviço</th>
                  <th className="pb-3 font-medium">Tempo Estimado</th>
                  <th className="pb-3 font-medium text-right">Valor Sugerido</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                <tr className="border-b border-zinc-800/50">
                  <td className="py-4 text-zinc-300">Consultoria / Reunião Avulsa</td>
                  <td className="py-4 text-zinc-500">1 hora</td>
                  <td className="py-4 text-white font-medium text-right">{formatCurrency(idealHourly)}</td>
                </tr>
                <tr className="border-b border-zinc-800/50">
                  <td className="py-4 text-zinc-300">Projeto Pequeno</td>
                  <td className="py-4 text-zinc-500">~{Math.round(data.hoursPerProject / 2)} horas</td>
                  <td className="py-4 text-white font-medium text-right">{formatCurrency((idealHourly * (data.hoursPerProject / 2)) + data.variableCosts)}</td>
                </tr>
                <tr className="border-b border-zinc-800/50">
                  <td className="py-4 text-zinc-300">Projeto Padrão (Seu foco)</td>
                  <td className="py-4 text-zinc-500">~{data.hoursPerProject} horas</td>
                  <td className="py-4 text-emerald-400 font-bold text-right">{formatCurrency(idealProject)}</td>
                </tr>
                <tr>
                  <td className="py-4 text-zinc-300">Projeto Complexo</td>
                  <td className="py-4 text-zinc-500">~{data.hoursPerProject * 2} horas</td>
                  <td className="py-4 text-white font-medium text-right">{formatCurrency((idealHourly * (data.hoursPerProject * 2)) + data.variableCosts)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
