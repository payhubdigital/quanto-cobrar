import { useState } from 'react';
import Landing from './components/Landing';
import Wizard from './components/Wizard';
import Result from './components/Result';

export type AppState = 'landing' | 'wizard' | 'result';

export default function App() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [formData, setFormData] = useState<any>(null);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-50 font-sans selection:bg-emerald-500/30">
      {appState === 'landing' && <Landing onStart={() => setAppState('wizard')} />}
      {appState === 'wizard' && (
        <Wizard 
          onComplete={(data) => {
            setFormData(data);
            setAppState('result');
          }} 
        />
      )}
      {appState === 'result' && (
        <Result 
          data={formData} 
          onRestart={() => {
            setFormData(null);
            setAppState('landing');
          }} 
        />
      )}
    </div>
  );
}
